Please find instructions on Slide 3 at:
https://docs.google.com/presentation/d/1C-8fXkeJctImsOaTs0CJvEuud6N4wZRM/edit?usp=sharing&ouid=108345240302188835018&rtpof=true&sd=true

